export class CreatePermissionDto {}

export class Permission {}

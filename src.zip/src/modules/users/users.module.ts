import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserListener } from   '../../listeners/user.listener';
import { UserSubscriber } from '../../subscribers/user.subscriber';

import { UsersService } from './users.service';
import { UsersController } from './users.controller';
import { User } from './entities/user.entity';
import { EventEmitterModule } from '@nestjs/event-emitter';
import { MailModule } from '../../shared/mail/mail.module';

import { MailQueueModule } from '../../queues/mail/mail.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([User]),
    EventEmitterModule.forRoot(), // 👈 once globally or here
    MailModule, // ✅ makes MailService injectable
    MailQueueModule, // 🔥 FIX
     
  ],
  controllers: [UsersController],
  providers: [
    UsersService,
    UserListener,
    UserSubscriber,
    
  ],
  exports: [UsersService],
})
export class UsersModule {}

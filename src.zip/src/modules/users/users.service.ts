import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

import { User } from './entities/user.entity';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import * as bcrypt from 'bcrypt';

@Injectable()
export class UsersService {
  constructor(
    @InjectRepository(User)
    private readonly userRepository: Repository<User>,
  ) {}

  // ✅ CREATE (Laravel: User::create())
  async create(createUserDto: CreateUserDto): Promise<User> {
    const user = this.userRepository.create(createUserDto);
    return await this.userRepository.save(user);
  }

  // ✅ FIND ALL (Laravel: User::all())
  async findAll(): Promise<User[]> {

    // const password = await bcrypt.hash('password123', 10);

    // const rand5 = Math.floor(10000 + Math.random() * 90000);
    // const createUserDto = 
    //   { name: 'Admin', email: `admin${rand5}@example.com`, password, role: 'admin', is_active: true };

    // const user = this.userRepository.create(createUserDto);
    //  await this.userRepository.save(user);


    return await this.userRepository.find();
  }

  // ✅ FIND ONE (Laravel: User::findOrFail())
  async findOne(id: number): Promise<User> {
    const user = await this.userRepository.findOne({
      where: { id },
    });

    if (!user) {
      throw new NotFoundException(`User #${id} not found`);
    }

    return user;
  }

  // ✅ UPDATE (Laravel: User::where()->update())
  async update(
    id: number,
    updateUserDto: UpdateUserDto,
  ): Promise<User> {
    await this.userRepository.update(id, updateUserDto);
    return this.findOne(id);
  }

  // ✅ DELETE (Laravel: User::destroy())
  async remove(id: number): Promise<void> {
    const result = await this.userRepository.delete(id);

    if (result.affected === 0) {
      throw new NotFoundException(`User #${id} not found`);
    }
  }
}

// src/auth/auth.controller.ts
// import { Controller, Post, Body } from '@nestjs/common';
// import { AuthService } from './auth.service';
// import { LoginAuthDto } from './dto/login-auth.dto';

// @Controller('auth')
// export class AuthController {
//   constructor(private readonly authService: AuthService) {}

//   @Post('login') // explicit route is better than POST /
//   login(@Body() loginAuthDto: LoginAuthDto) {
//      console.log("loginAuthDto", loginAuthDto);
//     return this.authService.login(loginAuthDto);
//   }
// }


import { Controller, Post, Body ,ValidationPipe} from '@nestjs/common';
 import { AuthService } from './auth.service';
import { LoginAuthDto } from './dto/login-auth.dto';

@Controller('admin')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Post('login')
  async login(@Body(new ValidationPipe()) loginAuthDto: LoginAuthDto) {
    return this.authService.login(loginAuthDto);
  }
}
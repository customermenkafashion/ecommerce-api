// import {
//   EventSubscriber,
//   EntitySubscriberInterface,
//   InsertEvent,
//   UpdateEvent,
//   RemoveEvent,
// } from 'typeorm';
// import { User } from '../modules/users/entities/user.entity';
// import { EventEmitter2 } from '@nestjs/event-emitter';
// // import { AppModule } from '../app.module'; // Optional: to access globally

// @EventSubscriber()
// export class UserSubscriber implements EntitySubscriberInterface<User> {
//   constructor(private eventEmitter: EventEmitter2) {}

//   listenTo() {
//     return User;
//   }

//   afterInsert(event: InsertEvent<User>) {
//     if (!event.entity) return; // safety check

//     console.log(`User inserted with id: ${event.entity.id}`);
//     this.eventEmitter.emit('user.created', {
//       id: event.entity.id,
//       name: event.entity.name,
//       email: event.entity.email,
//     });
//   }

//   afterUpdate(event: UpdateEvent<User>) {
//     if (!event.entity) return;

//     console.log(`User updated with id: ${event.entity.id}`);
//     // optional: emit 'user.updated' event
//     // this.eventEmitter.emit('user.updated', event.entity);
//   }

//   afterRemove(event: RemoveEvent<User>) {
//     // event.entity might be undefined, but event.entityId is always available
//     console.log(`User removed with id: ${event.entity?.id ?? event.entityId}`);
//     // optional: emit 'user.removed' event
//     // this.eventEmitter.emit('user.removed', { id: event.entity?.id ?? event.entityId });
//   }
// }




// import {
//   EventSubscriber,
//   EntitySubscriberInterface,
//   InsertEvent,
// } from 'typeorm';
// import { User } from '../modules/users/entities/user.entity';

// @EventSubscriber()
// export class UserSubscriber implements EntitySubscriberInterface<User> {
//     constructor() {
//     console.log('✅ UserSubscriber loaded');
//     }

//   listenTo() {
//     return User;
//   }

//   afterInsert(event: InsertEvent<User>) {
//     if (!event.entity) return;

//     console.log(`User inserted with id: ${event.entity.id}`);
//     // You **cannot** use EventEmitter2 here
//   }
// }


// import {
//   EventSubscriber,
//   EntitySubscriberInterface,
//   InsertEvent,
// } from 'typeorm';
// import { EventEmitter2 } from '@nestjs/event-emitter';
// import { User } from '../modules/users/entities/user.entity';

// @EventSubscriber()
// export class UserSubscriber implements EntitySubscriberInterface<User> {

//   constructor() {
//     console.log('✅ UserSubscriber registered');
//   }
  

//   listenTo() {
//     return User;
//   }

//   afterInsert(event: InsertEvent<User>) {
//     if (!event.entity) return;

//     console.log(`🔥 User inserted with id: ${event.entity.id}`);
//   }
// }


// import {
//   EventSubscriber,
//   EntitySubscriberInterface,
//   InsertEvent,
//   UpdateEvent,
//   RemoveEvent,
// } from 'typeorm';
// import { EventEmitter2 } from '@nestjs/event-emitter';
// import { User } from '../modules/users/entities/user.entity';

// @EventSubscriber()
// export class UserSubscriber implements EntitySubscriberInterface<User> {

//   constructor(private readonly eventEmitter: EventEmitter2) {
//     console.log('✅ UserSubscriber registered');
//   }

//   listenTo() {
//     return User;
//   }

//   // CREATE
//   afterInsert(event: InsertEvent<User>) {
//      console.log(`🔥 User inserted with id: ${event.entity.id}`);
//     if (!event.entity) return;

//     this.eventEmitter.emit(
//       'user.created',
//       {
//         id: event.entity.id,
//         name: event.entity.name,
//         email: event.entity.email,
//       },
//     );
//   }

//   // UPDATE
//   afterUpdate(event: UpdateEvent<User>) {
//     if (!event.entity) return;

//     this.eventEmitter.emit(
//       'user.updated',
//       {
//         id: event.entity.id,
//         name: event.entity.name,
//         email: event.entity.email,
//       },
//     );
//   }

//   // DELETE
//   afterRemove(event: RemoveEvent<User>) {
//     if (!event.entity) return;

//     this.eventEmitter.emit(
//       'user.deleted',
//       {
//         id: event.entity.id,
//         name: event.entity.name,
//         email: event.entity.email,
//       },
//     );
//   }
// }




// src/subscribers/user.subscriber.ts
import { Injectable, OnModuleInit } from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { DataSource } from 'typeorm';
import { User } from '../modules/users/entities/user.entity';
import { UserCreatedEvent, UserUpdatedEvent, UserDeletedEvent, UserRestoredEvent } from '../events/user.event';

@Injectable()
export class UserSubscriber implements OnModuleInit {
  constructor(
    private readonly dataSource: DataSource,
    private readonly eventEmitter: EventEmitter2,
  ) {
    console.log('✅ UserSubscriber created');
  }

  onModuleInit() {
    // Register a manual TypeORM subscriber using the NestJS EventEmitter
    this.dataSource.subscribers.push({
      listenTo: () => User,
      afterInsert: (event) => {
        if (!event.entity) return;

        console.log('🔥 User inserted, emitting user.created');
        this.eventEmitter.emit(
          'user.created',
          new UserCreatedEvent(
            event.entity.id,
            event.entity.name,
            event.entity.email,
          ),
        );
      },
      afterUpdate: (event) => {
        if (!event.entity) return;

        console.log('🔥 User updated, emitting user.updated');
        this.eventEmitter.emit(
          'user.created',
          new UserUpdatedEvent(
            event.entity.id,
            event.entity.name,
            event.entity.email,
          ),
        );
      },
      afterRemove: (event) => {
        if (!event.entity) return;

        console.log('🔥 User deleted, emitting user.removed');
        this.eventEmitter.emit(
          'user.created',
          new UserDeletedEvent(
            event.entity.id,
            event.entity.name,
            event.entity.email,
          ),
        );
      },
       afterRetored: (event) => {
        if (!event.entity) return;

        console.log('🔥 User deleted, emitting user.removed');
        this.eventEmitter.emit(
          'user.created',
          new UserRestoredEvent(
            event.entity.id,
            event.entity.name,
            event.entity.email,
          ),
        );
      },
    } as any);
  }
}

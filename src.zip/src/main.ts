import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';

import { HttpErrorFilter } from './common/filters/http-exception.filter';
import { TransformInterceptor } from './common/interceptors/transform.interceptor';


import { ValidationPipe, BadRequestException } from '@nestjs/common';
import * as bodyParser from 'body-parser';
import { Logger } from '@nestjs/common';
import * as multer from 'multer';
// ✅ Common imports
import { AppValidationPipe } from './common/pipes/validation.pipe';
import { ResponseInterceptor } from './common/interceptors/response.interceptor';
// import { HttpExceptionFilter } from './common/filters/http-exception.filter';

// import { useContainer } from 'typeorm';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  // ✅ GLOBAL MIDDLEWARES (ORDER MATTERS)
  app.useGlobalFilters(new HttpErrorFilter());  
  app.useGlobalInterceptors(new TransformInterceptor());
  // app.useGlobalPipes(AppValidationPipe);
  // app.useGlobalInterceptors(new ResponseInterceptor());
  // app.useGlobalFilters(new HttpExceptionFilter());

  // useContainer(app.select(AppModule), { fallbackOnErrors: true });

  app.enableCors({ 
    origin: '*', // Allow all origins (Change this to frontend domain in production)
    methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
    allowedHeaders: 'Content-Type, Authorization',
  });


  app.use((req, res, next) => {
    console.log("gggggggggggggggggggggggggggggggggggggggggggg");
    Logger.log(`Incoming Request: ${req.method} ${req.url}`);
    Logger.log(`Headers: ${JSON.stringify(req.headers, null, 2)}`);
    Logger.log(`Body: ${JSON.stringify(req.body, null, 2)}`);
    next();
  });

  app.use(bodyParser.json()); // Parses JSON requests
  app.use(bodyParser.urlencoded({ extended: true })); // Parses URL-encoded form data

  // This will automatically validate all DTOs
   app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      transform: true,
      // forbidUnknownValues: true,
      // exceptionFactory: (errors) => {
      //   return new BadRequestException(errors);
      // },
    }),
  );

  app.enableCors();


  

  const port = process.env.PORT || 3000;
  await app.listen(port);

  console.log(`🚀 Server running on http://localhost:${port}`);

}
bootstrap();

export const MESSAGES = {
  USER_CREATED: 'User created successfully',
  USER_NOT_FOUND: 'User not found',
  UNAUTHORIZED: 'Unauthorized access',
};

export const APP_NAME = 'Enterprise E-Commerce API';
export const API_VERSION = 'v1';

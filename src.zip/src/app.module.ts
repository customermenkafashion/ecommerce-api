// import { Module } from '@nestjs/common';
// import { TypeOrmModule } from '@nestjs/typeorm';
// import { ConfigModule, ConfigService } from '@nestjs/config';
// import { AppController } from './app.controller';
// import { AppService } from './app.service';
// import { ProductsModule } from './modules/products/products.module';
// import { AddressesModule } from './modules/addresses/addresses.module';
// import { PermissionsModule } from './modules/permissions/permissions.module';
// import { RolesModule } from './modules/roles/roles.module';
// import { CartModule } from './modules/cart/cart.module';
// import { ReviewsModule } from './modules/reviews/reviews.module';
// import { PaymentsModule } from './modules/payments/payments.module';
// import { OrderItemsModule } from './modules/order-items/order-items.module';
// import { OrdersModule } from './modules/orders/orders.module';
// import { CategoriesModule } from './modules/categories/categories.module';
// import { UsersModule } from './modules/users/users.module';
// import { AuthModule } from './modules/auth/auth.module';

// import appConfig from './config/app.config';
// import databaseConfig from './config/database.config';
// import jwtConfig from './config/jwt.config';
// import redisConfig from './config/redis.config';

// import { HealthModule } from './health/health.module';

// import { UserSubscriber } from './subscribers/user.subscriber';

// @Module({
  
//   imports: [
    
//     ConfigModule.forRoot({
//       isGlobal: true,
//       load: [appConfig, databaseConfig, jwtConfig, redisConfig],
//     }),

//     TypeOrmModule.forRootAsync({
//       inject: [ConfigService],
//       useFactory: (config: ConfigService) => ({
//         ...config.get('database'),
//       }),

//       dataSourceFactory: async (options) => {
//         if (!options) {
//           throw new Error('TypeORM options are undefined');
//         }

//         const dataSource = new DataSource(options);
//         await dataSource.initialize();

//         dataSource.subscribers.push(new UserSubscriber());

//         return dataSource;
//       },


//     }),
    
//       ProductsModule, AuthModule, UsersModule, CategoriesModule,
//       OrdersModule, OrderItemsModule, PaymentsModule, ReviewsModule,
//       CartModule, RolesModule, PermissionsModule, AddressesModule,
//       HealthModule,
//       // UserSubscriber
//     ],
//     controllers: [AppController],
//     providers: [AppService],
//   })
//   export class AppModule {}


// import { Module } from '@nestjs/common';
// import { TypeOrmModule } from '@nestjs/typeorm';
// import { ConfigModule, ConfigService } from '@nestjs/config';
// import { DataSource } from 'typeorm';

// import { AppController } from './app.controller';
// import { AppService } from './app.service';

// import { ProductsModule } from './modules/products/products.module';
// import { UsersModule } from './modules/users/users.module';
// import { AuthModule } from './modules/auth/auth.module';
// import { CategoriesModule } from './modules/categories/categories.module';
// import { OrdersModule } from './modules/orders/orders.module';
// import { OrderItemsModule } from './modules/order-items/order-items.module';
// import { PaymentsModule } from './modules/payments/payments.module';
// import { ReviewsModule } from './modules/reviews/reviews.module';
// import { CartModule } from './modules/cart/cart.module';
// import { RolesModule } from './modules/roles/roles.module';
// import { PermissionsModule } from './modules/permissions/permissions.module';
// import { AddressesModule } from './modules/addresses/addresses.module';
// import { HealthModule } from './health/health.module';

// import appConfig from './config/app.config';
// import databaseConfig from './config/database.config';
// import jwtConfig from './config/jwt.config';
// import redisConfig from './config/redis.config';

// import { UserSubscriber } from './subscribers/user.subscriber';
// import { EventEmitterModule, EventEmitter2 } from '@nestjs/event-emitter';

// import { UserCreatedEvent } from   './events/user.event';
// import { UserListener } from './listeners/user.listener';

// @Module({
//   imports: [
//     ConfigModule.forRoot({
//       isGlobal: true,
//       load: [appConfig, databaseConfig, jwtConfig, redisConfig],
//     }),

//     EventEmitterModule.forRoot(), // ✅ REQUIRED

//     TypeOrmModule.forRootAsync({
//       inject: [ConfigService],
//       useFactory: (config: ConfigService) => ({
//         ...config.get('database'),
//       }),


//       dataSourceFactory: async (options) => {
//         if (!options) {
//           throw new Error('TypeORM options are undefined');
//         }

//         const dataSource = new DataSource(options);
//         await dataSource.initialize();

//         dataSource.subscribers.push(new UserSubscriber(new EventEmitter2()));

//         // ✅ SAME EventEmitter instance
//         // dataSource.subscribers.push(
//         //   new UserSubscriber(EventEmitter2),
//         // );

//         return dataSource;

//         // const dataSource = new DataSource(options);
//         // return dataSource.initialize(); // ✅ no manual subscriber
//       },
//     }),


//     ProductsModule,
//     AuthModule,
//     UsersModule,
//     CategoriesModule,
//     OrdersModule,
//     OrderItemsModule,
//     PaymentsModule,
//     ReviewsModule,
//     CartModule,
//     RolesModule,
//     PermissionsModule,
//     AddressesModule,
//     HealthModule,
//   ],
//   controllers: [AppController],
//   providers: [AppService, UserListener, UserCreatedEvent],
// })
// export class AppModule {}



// // app.module.ts
// import { Module } from '@nestjs/common';
// import { TypeOrmModule } from '@nestjs/typeorm';
// import { ConfigModule, ConfigService } from '@nestjs/config';
// import { EventEmitterModule } from '@nestjs/event-emitter';

// import appConfig from './config/app.config';
// import databaseConfig from './config/database.config';
// import jwtConfig from './config/jwt.config';
// import redisConfig from './config/redis.config';

// import { UsersModule } from './modules/users/users.module';
// import { UserSubscriber } from './subscribers/user.subscriber';
// import { UserListener } from './listeners/user.listener';

// @Module({
//   imports: [
//     ConfigModule.forRoot({
//       isGlobal: true,
//       load: [appConfig, databaseConfig, jwtConfig, redisConfig],
//     }),

//     EventEmitterModule.forRoot(), // ✅ ONE global emitter

//     TypeOrmModule.forRootAsync({
//       inject: [ConfigService],
//       useFactory: (config: ConfigService) => ({
//         ...config.get('database'),
//         autoLoadEntities: true,
//         subscribers: [UserSubscriber], // ✅ REGISTER subscriber properly
//       }),
//     }),

//     UsersModule,
//   ],
//   providers: [UserSubscriber, UserListener],
// })
// export class AppModule {}


// src/app.module.ts
import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { DataSource } from 'typeorm';

import { AppController } from './app.controller';
import { AppService } from './app.service';

import { ProductsModule } from './modules/products/products.module';
import { UsersModule } from './modules/users/users.module';
import { AuthModule } from './modules/auth/auth.module';
import { CategoriesModule } from './modules/categories/categories.module';
import { OrdersModule } from './modules/orders/orders.module';
import { OrderItemsModule } from './modules/order-items/order-items.module';
import { PaymentsModule } from './modules/payments/payments.module';
import { ReviewsModule } from './modules/reviews/reviews.module';
import { CartModule } from './modules/cart/cart.module';
import { RolesModule } from './modules/roles/roles.module';
import { PermissionsModule } from './modules/permissions/permissions.module';
import { AddressesModule } from './modules/addresses/addresses.module';
import { HealthModule } from './health/health.module';

import appConfig from './config/app.config';
import databaseConfig from './config/database.config';
import jwtConfig from './config/jwt.config';
import redisConfig from './config/redis.config';

import { BullModule } from '@nestjs/bull';
import { JwtModule } from '@nestjs/jwt';

import { MailService } from './shared/mail/mail.service';


import { RequestIdMiddleware } from './middlewares/request-id/request-id.middleware';
import { LoggerMiddleware } from './middlewares/logger/logger.middleware';
import { AuthMiddleware } from './middlewares/auth/auth.middleware';
import { UserContextMiddleware } from './middlewares/user-context/user-context.middleware';

@Module({
  imports: [
    JwtModule.register({
      secret: process.env.JWT_SECRET || 'secret123',
      signOptions: { expiresIn: '1d' },
    }),


    BullModule.forRoot({
      redis: {
        host: '127.0.0.1',
        port: 6379,
      },
    }),

    BullModule.registerQueue({
      name: 'mail',
    }),

    ConfigModule.forRoot({
      isGlobal: true,
      load: [appConfig, databaseConfig, jwtConfig, redisConfig],
    }),

    TypeOrmModule.forRootAsync({
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        ...config.get('database'),
      }),
    }),

    ProductsModule,
    AuthModule,
    UsersModule,
    CategoriesModule,
    OrdersModule,
    OrderItemsModule,
    PaymentsModule,
    ReviewsModule,
    CartModule,
    RolesModule,
    PermissionsModule,
    AddressesModule,
    HealthModule,
  ],
  controllers: [AppController],
  providers: [
    AppService,
    MailService,
  ],
})

export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(
        RequestIdMiddleware,
        LoggerMiddleware,
        AuthMiddleware,
        UserContextMiddleware,
      )
      .forRoutes('*'); // global
  }
}



